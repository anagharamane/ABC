# Node-Mcu-HTTP-REST-Server
#### This is a code to create a HTTP REST Server on Node-MCU

>Connecting to an existing Wi-Fi network
 >
 >Setting up Node MCU as an Wi-Fi Access Point
 >
 >Create a HTTP Server hosted by Node MCU
 >
 >DNS masking of IP assigned by the AP
 >
 >Controlling GPIO Through REST APIs
 >
 >Reading ADC Value through REST APIs

* Author: Sanyam Arya
* ersanyamarya@gmail.com
* https://www.facebook.com/er.sanyam.arya
* https://www.linkedin.com/in/sanyam-arya-077ab638/
